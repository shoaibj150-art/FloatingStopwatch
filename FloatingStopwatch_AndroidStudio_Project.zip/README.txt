FLOATING STOPWATCH - Android Studio project

Features:
- Digital HH:MM:SS stopwatch
- Floating overlay above other apps
- Drag the top title strip to move the timer
- Start/Pause, Reset, and Close controls
- Foreground notification while running

Build:
1. Install Android Studio.
2. Open the FloatingStopwatch folder (or extracted ZIP) in Android Studio.
3. Let Gradle sync finish.
4. Connect an Android phone or select an emulator.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated APK.

First run:
1. Open Floating Stopwatch.
2. Tap "Show Floating Stopwatch".
3. Android Settings opens for "Display over other apps".
4. Enable permission and return to the app.
5. Tap "Show Floating Stopwatch" again.

Notes:
- This is a source project ZIP, not a prebuilt APK.
- Android may restrict background services on some phone brands. Keep the app's battery use unrestricted if the overlay is stopped by the phone.
- The foreground notification is expected while the floating stopwatch is active.
