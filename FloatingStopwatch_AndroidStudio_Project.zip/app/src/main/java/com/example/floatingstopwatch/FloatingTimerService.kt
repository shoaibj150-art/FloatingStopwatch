package com.example.floatingstopwatch

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class FloatingTimerService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private var timeView: TextView? = null
    private var running = false
    private var accumulatedMs = 0L
    private var startedAt = 0L
    private val handler = android.os.Handler()
    private val tick = object : Runnable {
        override fun run() {
            timeView?.text = formatTime(elapsed())
            handler.postDelayed(this, 200L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Stopwatch")
            .setContentText("Stopwatch overlay is active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    private fun showOverlay() {
        if (overlay != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.rgb(18, 24, 38))
        }

        val dragHandle = TextView(this).apply {
            text = "⠿  FLOATING STOPWATCH"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 6)
        }

        timeView = TextView(this).apply {
            text = "00:00:00"
            textSize = 27f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 8)
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val playPause = makeButton(if (running) "PAUSE" else "START")
        val reset = makeButton("RESET")
        val close = makeButton("×")

        playPause.setOnClickListener {
            if (running) pauseStopwatch() else resumeStopwatch()
            playPause.text = if (running) "PAUSE" else "START"
        }
        reset.setOnClickListener {
            accumulatedMs = 0L
            if (running) startedAt = SystemClock.elapsedRealtime()
            timeView?.text = "00:00:00"
        }
        close.setOnClickListener { stopSelf() }

        controls.addView(playPause)
        controls.addView(reset)
        controls.addView(close)
        root.addView(dragHandle)
        root.addView(timeView)
        root.addView(controls)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 180
        }

        var initialX = 0
        var initialY = 0
        var downX = 0f
        var downY = 0f
        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - downX).toInt()
                    params.y = initialY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(root, params)
                    true
                }
                else -> false
            }
        }

        overlay = root
        windowManager.addView(root, params)
        handler.post(tick)
    }

    private fun makeButton(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(10, 10, 10, 10)
        setBackgroundColor(Color.rgb(45, 60, 85))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.setMargins(3, 0, 3, 0)
        layoutParams = lp
    }

    private fun resumeStopwatch() {
        if (!running) {
            startedAt = SystemClock.elapsedRealtime()
            running = true
        }
    }

    private fun pauseStopwatch() {
        if (running) {
            accumulatedMs += SystemClock.elapsedRealtime() - startedAt
            running = false
        }
    }

    private fun elapsed(): Long =
        accumulatedMs + if (running) SystemClock.elapsedRealtime() - startedAt else 0L

    private fun formatTime(ms: Long): String {
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Floating Stopwatch", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        overlay?.let { windowManager.removeView(it) }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "floating_stopwatch_channel"
        private const val NOTIFICATION_ID = 1001
    }
}
