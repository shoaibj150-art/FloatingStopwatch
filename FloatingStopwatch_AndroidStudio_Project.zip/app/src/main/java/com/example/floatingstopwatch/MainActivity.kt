package com.example.floatingstopwatch

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(0xFF101827.toInt())
        }

        val title = TextView(this).apply {
            text = "FLOATING STOPWATCH"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Digital stopwatch jo doosri apps ke upar bhi nazar aayega. Overlay permission zaroori hai."
            textSize = 16f
            setTextColor(0xFFD1D5DB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }
        val start = Button(this).apply {
            text = "Show Floating Stopwatch"
            setOnClickListener { startFloatingStopwatch() }
        }
        val stop = Button(this).apply {
            text = "Close Floating Stopwatch"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingTimerService::class.java))
                Toast.makeText(this@MainActivity, "Stopwatch overlay closed", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun startFloatingStopwatch() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Allow 'Display over other apps', then open app again.", Toast.LENGTH_LONG).show()
            return
        }
        val serviceIntent = Intent(this, FloatingTimerService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        Toast.makeText(this, "Floating stopwatch started", Toast.LENGTH_SHORT).show()
    }
}
